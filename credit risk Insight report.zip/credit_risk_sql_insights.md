# Give Me Some Credit — SQL Analysis Insights
**Project:** Credit Risk SQL Analysis  
**Dataset:** Give Me Some Credit (Kaggle)  
**Author:** Francis Selasi Ava (github.com/selasieava)  
**Tool:** SQL Server (SSMS)  

---

## Overview

This document records all analytical insights derived from structured SQL queries on the Give Me Some Credit dataset (~150,000 borrower records). The goal is to understand the drivers of financial distress (`SeriousDlqin2yrs`) before building a predictive model in Python.

---

## Phase 1 — Data Quality & Distributions

### Key Facts
- Target variable: `SeriousDlqin2yrs` (1 = serious delinquency within 2 years, 0 = no delinquency)
- Dataset is heavily **class imbalanced** — approximately 93% of records are class 0 (no default)
- Two columns have missing values: `MonthlyIncome` (~20% missing) and `NumberOfDependents` (~2.6% missing)
- Some `age` values are 0 or unrealistically low — likely data entry errors
- Some `RevolvingUtilizationOfUnsecuredLines` values exceed 1.0 — borrowers over their credit limit
- Some `DebtRatio` values are extremely high (even in the thousands) — likely caused by zero or missing income in the denominator

---

## Phase 2 — Feature Deep Dives

### 2A. Revolving Utilization of Unsecured Lines

**Query:** Borrowers bucketed by RevolvingUtilizationOfUnsecuredLines with default rate per bucket.

**Results:**

| Utilization Bucket | Total | Defaulted | Default Rate |
|---|---|---|---|
| Very High (>1.0) | 3,321 | 1,237 | 37.25% |
| High (0.6–1.0) | 31,910 | 5,266 | 16.50% |
| Medium (0.3–0.6) | 21,887 | 1,462 | 6.68% |
| Low (<0.3) | 92,882 | 2,061 | 2.22% |

**Insights:**

**Insight 1 — Utilization is the single most powerful predictor in the dataset.**  
Default rate increases sharply and consistently across every bucket — a clean **17× spread** from Low (2.22%) to Very High (37.25%). No other single feature examined produces this level of discrimination. This variable is expected to be the top feature in the final model.

**Insight 2 — Being over the credit limit is catastrophic.**  
The Very High bucket (>1.0) represents borrowers spending beyond their credit limit. Over **1 in 3** of these borrowers (37.25%) default within 2 years. With 3,321 records this is a meaningful group — not outlier noise — and should be treated as a distinct high-risk flag in feature engineering.

**Insight 3 — Even moderate utilization doubles baseline default risk.**  
Borrowers in the Medium bucket (0.3–0.6) default at 6.68% — already **3× the Low bucket rate** of 2.22%. Credit risk starts climbing well before borrowers approach their limit, suggesting a non-linear relationship that tree-based models (XGBoost, Random Forest) will capture better than logistic regression.

**Insight 4 — Low utilization is the strongest single protective factor in the dataset.**  
A utilization below 0.3 produces a 2.22% default rate — lower even than the Very High income group (4.32%). This means **how a borrower uses their credit is a stronger safety signal than how much they earn**.

### 2B. Monthly Income

**Query:** Borrowers bucketed by MonthlyIncome (including NULL as its own category) with default rate per bucket.

**Results:**

| Income Bucket | Total | Defaulted | Default Rate |
|---|---|---|---|
| Very High (>10k) | 18,319 | 792 | 4.32% |
| High (6k–10k) | 32,876 | 1,834 | 5.58% |
| Missing | 29,731 | 1,669 | 5.61% |
| Medium (3k–6k) | 45,748 | 3,624 | 7.92% |
| Low (<3k) | 23,326 | 2,107 | 9.03% |

**Insights:**

**Insight 1 — Income has a clean inverse relationship with default rate.**  
Unlike debt ratio, income follows a perfectly logical gradient — the lower the income, the higher the default rate, with no anomalies. This makes `MonthlyIncome` a reliable and interpretable predictor once missing values are handled.

**Insight 2 — Missing income sits between High and Medium income groups.**  
Borrowers with missing income default at **5.61%** — almost identical to the High income group (5.58%) and well below Medium and Low. This contrasts with the Phase 3 cross-feature result where missing income tracked closer to Low income within utilization buckets. This suggests missing income borrowers are a **heterogeneous group** — some genuinely high earners who did not report, others with unstable or low income. Simple mean imputation would distort the signal; retaining missingness as an explicit category or using median imputation by risk segment is more appropriate.

**Insight 3 — Income is a moderate standalone predictor.**  
The spread from lowest to highest default rate is 4.32% to 9.03% — approximately a 2× difference. This is meaningful but far less dramatic than utilization (20× spread). Income is most powerful as a **modifier** of other features rather than a primary standalone predictor.

**Insight 4 — Low income borrowers are the most financially vulnerable group.**  
The Low income bucket (<3k/month) carries a **9.03% default rate** — the highest of any income group. When combined with high utilization (from Phase 3), low income + very high utilization produces default rates above 37%, making this the most at-risk combination in the dataset.

### 2C. Debt Ratio

**Query:** Borrowers bucketed by DebtRatio with default rate per bucket.

**Results:**

| Debt Ratio Bucket | Total | Defaulted | Default Rate |
|---|---|---|---|
| High (0.6–1.0) | 12,768 | 1,338 | 10.48% |
| Medium (0.3–0.6) | 39,535 | 2,723 | 6.89% |
| Very High (>1.0) | 35,155 | 2,291 | 6.52% |
| Low (<0.3) | 62,542 | 3,674 | 5.87% |

**Insights:**

**Insight 1 — Debt ratio has a weak and non-linear relationship with default.**  
Unlike utilization, which cleanly stratifies risk from Low to Very High, debt ratio does not follow a consistent gradient. The High bucket (0.6–1.0) has the highest default rate at **10.48%**, but the Very High bucket (>1.0) drops back down to **6.52%** — lower than High. This non-linearity points to data quality issues rather than a genuine pattern.

**Insight 2 — The Very High bucket is distorted by outliers.**  
As identified in Phase 1, some `DebtRatio` values are in the hundreds or thousands — caused by borrowers with zero or near-zero recorded income in the denominator. These extreme values inflate the Very High bucket with unreliable records, suppressing its apparent default rate. These outliers must be capped or removed during Python preprocessing before this variable is used in modelling.

**Insight 3 — Debt ratio is a weaker standalone predictor than utilization.**  
The spread of default rates across debt ratio buckets (5.87% to 10.48%) is narrow compared to utilization (2% to 41%). This suggests `DebtRatio` alone carries limited discriminative power, though it may still contribute meaningfully in combination with other features inside the model.

**Insight 4 — Debt ratio may recover signal when combined with income.**  
In Python, deriving actual estimated monthly debt payments (`DebtRatio × MonthlyIncome`) may produce a more interpretable and predictive feature than the raw ratio, particularly for borrowers where income is known.

### 2D. Delinquency History

**Query:** Cross-tabulation of all three delinquency flags grouped by unique combination, with default rate per group.

**Key rows from results:**

| 30-59 Days Late | 60-89 Days Late | 90+ Days Late | Total | Defaulted | Default Rate |
|---|---|---|---|---|---|
| 0 | 0 | 0 | 119,637 | 3,264 | 2.73% |
| 1 | 0 | 0 | 12,774 | 1,179 | 9.23% |
| 0 | 0 | 1 | 2,332 | 550 | 23.58% |
| 1 | 1 | 1 | 256 | 100 | 39.06% |
| 98 | 98 | 98 | 264 | 143 | 54.17% |
| 96 | 96 | 96 | 5 | 4 | 80.00% |
| Multiple high combos | | | small groups | all | 100.00% |

**Insights:**

**Insight 1 — Clean borrowers dominate but are low risk.**  
Borrowers with zero delinquency across all three flags (`0,0,0`) make up approximately **80% of the dataset** (119,637 records) and default at just **2.73%**. This is the clean borrower baseline and a major contributor to class imbalance.

**Insight 2 — Any delinquency history is a severe risk signal.**  
The moment any delinquency flag becomes non-zero, default rates jump sharply. Even just one 30-59 day late event (`1,0,0`) raises the default rate to **9.23%** — more than 3× the baseline.

**Insight 3 — The 90-days-late flag is the most dangerous single indicator.**  
A single 90-day late event with no other flags (`0,0,1`) produces a **23.58%** default rate — nearly 9× the clean borrower baseline. Combinations where `NumberOfTimes90DaysLate > 0` dominate the high-risk end of the table, with many small groups reaching **100% default rates**.

**Insight 4 — Delinquency combinations are more predictive than any single flag.**  
The worst default rates consistently come from borrowers with high values across multiple delinquency columns simultaneously. This suggests that a **composite delinquency score** (sum or weighted combination of all three flags) will be a valuable engineered feature in the Python model.

**Insight 5 — The 96/98 sentinel values are a data quality issue.**  
Rows where all three delinquency columns equal **96** or **98** are almost certainly error or placeholder codes, not real delinquency counts. Notably, the `(98,98,98)` group contains **264 records** with a 54.17% default rate — a large enough group to influence the model if not handled. These records must be explicitly recoded (as missing or removed) during preprocessing in Python.

---

## Phase 3 — Cross-Feature Analysis

### 3A. Income Bucket × Utilization Bucket

**Query results:**

| income_bucket | utilization_bucket | total | defaulted | default_rate |
|---|---|---|---|---|
| Medium (3k-6k) | Very High | 1,195 | 492 | 41.17% |
| Missing | Very High | 548 | 207 | 37.77% |
| Low (<3k) | Very High | 810 | 304 | 37.53% |
| High (>6k) | Very High | 768 | 234 | 30.47% |
| Low (<3k) | High | 6,745 | 1,208 | 17.91% |
| Medium (3k-6k) | High | 10,547 | 1,877 | 17.80% |
| Missing | High | 5,603 | 982 | 17.53% |
| High (>6k) | High | 9,015 | 1,199 | 13.30% |
| Medium (3k-6k) | Medium | 7,288 | 562 | 7.71% |
| Low (<3k) | Medium | 3,142 | 240 | 7.64% |
| Missing | Medium | 2,884 | 187 | 6.48% |
| High (>6k) | Medium | 8,573 | 473 | 5.52% |
| Low (<3k) | Low | 12,629 | 355 | 2.81% |
| Medium (3k-6k) | Low | 26,718 | 693 | 2.59% |
| High (>6k) | Low | 32,839 | 720 | 2.19% |
| Missing | Low | 20,696 | 293 | 1.42% |

**Insights:**

**Insight 1 — Utilization is the dominant default driver.**  
Across all income levels, revolving utilization bucket almost perfectly stratifies default risk. Borrowers in the Very High utilization group default at rates between 30–41%, compared to just 1–3% for Low utilization borrowers. Utilization is expected to be one of the strongest predictors in the final model.

| Utilization Bucket | Default Rate Range |
|---|---|
| Very High (>1.0) | 30% – 41% |
| High (0.6–1.0) | 13% – 18% |
| Medium (0.3–0.6) | 5% – 8% |
| Low (<0.3) | 1% – 3% |

**Insight 2 — High income does not offset very high credit utilization.**  
Even borrowers earning over $6,000/month default at a rate of 30.47% when their utilization is Very High. This suggests that credit behaviour (how much of available credit is used) is a stronger signal than income level alone.

**Insight 3 — Missing income behaves like low income.**  
Borrowers with missing `MonthlyIncome` have default rates that closely track the Low income group across all utilization buckets. This suggests that income missingness is not random — these individuals likely have low or unstable income. For modelling purposes, missingness should be treated as an informative category rather than simply imputed.

**Insight 4 — The riskiest and safest borrower profiles are clearly identifiable in SQL.**  
- **Riskiest group:** Medium income (3k–6k) + Very High utilization → **41.17% default rate**  
- **Safest group:** High income (>6k) + Low utilization → **2.19% default rate**  
- The riskiest group is approximately **19× more likely** to default than the safest group.

---

## Phase 4 — Composite Risk Scoring

**Query:** Each borrower scored 0–5 based on five binary risk flags (high utilization, high debt ratio, any 90-day late event, low/missing income, age under 30), then grouped into Low/Medium/High Risk tiers.

**Results:**

| Risk Tier | Total | Defaulted | Default Rate |
|---|---|---|---|
| High Risk (score ≥ 3) | 12,924 | 2,855 | 22.09% |
| Medium Risk (score = 2) | 39,299 | 3,079 | 7.83% |
| Low Risk (score ≤ 1) | 97,777 | 4,092 | 4.19% |

**Insights:**

**Insight 1 — The composite score successfully separates borrowers into three distinct risk tiers.**  
Despite being a simple additive score with no machine learning, the risk tiers produce meaningfully different default rates — a **5× spread** from Low Risk (4.19%) to High Risk (22.09%). This demonstrates that the key risk variables identified in Phases 2 and 3 carry genuine combined predictive power.

**Insight 2 — High Risk borrowers are rare but extremely dangerous.**  
Only 12,924 borrowers (~8.6% of the dataset) fall into the High Risk tier, yet they account for **2,855 defaults** — nearly as many defaults as the Low Risk tier despite having 7.5× fewer borrowers. This group warrants the most attention in any credit decision or intervention system.

**Insight 3 — The majority of borrowers are Low Risk.**  
97,777 borrowers (~65% of the dataset) are Low Risk with a 4.19% default rate. This tier is largely safe but still contains 4,092 defaults — a reminder that even low-risk borrowers are not default-free, and that a purely rule-based system has limits.

**Insight 4 — A simple rule-based score can do surprisingly useful work.**  
Without any machine learning, five binary flags produce a composite score that achieves a 22.09% default rate in the top tier. This validates the feature selection from SQL analysis and establishes a strong interpretable baseline for the Python model to beat.

---

## Summary of Variables by Predictive Importance (SQL Evidence)

| Feature | Evidence of Predictive Power |
|---|---|
| `RevolvingUtilizationOfUnsecuredLines` | Very strong — 17× default rate spread from Low (2.22%) to Very High (37.25%); strongest single predictor in the dataset; being over credit limit (>1.0) flags 1 in 3 borrowers as defaulters |
| Delinquency flags (all three) | Very strong — default rate rises from 2.73% (clean) to 100% (heavy multi-flag combinations); 90-day flag is the single strongest indicator |
| `MonthlyIncome` | Moderate — clean inverse relationship with default (4.32% to 9.03%); most powerful as a modifier of utilization; missing values are informative and should not be naively imputed |
| `DebtRatio` | Weak standalone — non-linear relationship with default, likely distorted by extreme outliers from zero-income records; may recover signal when multiplied by income |
| `age` | Mild — younger borrowers show higher default rates; confirmed via age group query in Phase 1 |

---

## Key Preprocessing Actions Identified for Python

Based on all SQL analysis, the following data quality issues must be addressed before modelling:

1. **Recode 96/98 sentinel values** in all three delinquency columns — treat as missing or remove
2. **Cap or remove extreme DebtRatio outliers** — values in the hundreds/thousands are artifacts of zero income
3. **Handle MonthlyIncome missingness explicitly** — retain as a category or impute by risk segment; do not use simple mean imputation
4. **Flag and investigate age = 0 records** — likely data entry errors
5. **Address class imbalance** — ~93% class 0; use SMOTE, class weighting, or undersampling
6. **Engineer a composite delinquency score** — sum of all three delinquency flags as a new feature
7. **Engineer a monthly debt payment estimate** — `DebtRatio × MonthlyIncome` where income is known

---

*SQL analysis complete. Next phase: Python EDA, preprocessing, and model building.*
